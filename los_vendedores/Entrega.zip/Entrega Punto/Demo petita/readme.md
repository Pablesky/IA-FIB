Per executar la petita mostra, si escrius al terminal -> clips -f executar_cas_acceptable.clips

-El fitxer cass_acceptable conte les dades del programa
-ontologia.clips el maeix que posa el nom
-rules.clips el programa
