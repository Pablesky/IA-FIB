clips -f executar.clips
