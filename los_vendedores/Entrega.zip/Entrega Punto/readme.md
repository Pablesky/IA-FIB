Intruccions per a poder executar la demo.

A l'arrel d'aquest fitxer tens la segurament entrega final del nostre grup.
El contingut es el seguent:

  -La carpeta /Demo Petita, que es la primera demo del nostre programa, dins hi ha un altre readme per poder executar-la
  i la explicació dels fitxers que la compossen.

  -El fitxer data.clips que conté les dades de serveis i llocs de la ciutat de Barcelona.

  -El fitxer executar_demo.clips que conté les comandes per a poder executar el programa.

  -Els fitxers executar.sh i un Makefile, qualsevol de les dues opcions haurien de funcionar, per si un cas, si copies
  i enganxes aquesta comanda a la teva terminal hauria de funcionar -> clips -f executar_demo.clips

  -El fitxer ontologia.clips, que com bé diu el nom, és la ontologia.

  -El fitxer rules.clips que conté el codi del programa que ens dona la solucio.
