package los_camioneros.implementation;

import aima.search.framework.GoalTest;

public class CamionesGoalTest implements GoalTest {

	public boolean isGoalState(Object arg0) {
		return false;
	}

}
